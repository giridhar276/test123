"""Travel Planner — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Travel Planner", page_icon="🤖")
st.title("Travel Planner")
st.caption("Single agent | Beginner-friendly LangChain OpenAI demo")
st.markdown("A single agent turns a traveler’s preferences into a simple itinerary. It demonstrates how an agent interprets a request and produces a useful response.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Travel request", value="Plan a two-day Hyderabad visit for a family that likes history and vegetarian food. Budget is moderate.")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "You are a friendly travel planner. Give a practical 2-day itinerary using the traveler preferences. Keep it concise and mention assumptions.\n\n" + request  # Combine role instructions with the participant's request.
        result = llm.invoke(prompt)  # Ask the agent to produce an itinerary.
        st.markdown(result.content)  # Show the answer in the app.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
