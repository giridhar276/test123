"""Meeting Notes Assistant — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Meeting Notes Assistant", page_icon="🤖")
st.title("Meeting Notes Assistant")
st.caption("Single agent transforms input | Beginner-friendly LangChain OpenAI demo")
st.markdown("The agent converts rough meeting notes into a summary, action items, and a follow-up draft. It demonstrates a practical workplace task without extra tools.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Meeting notes", value="We discussed the demo for Friday. Anika will update slides by Wednesday. Need sample data; Ravi to share it tomorrow. Check if the room is booked.", height=150)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "Turn the notes into Summary, Action items, and a Follow-up email draft. Do not invent details.\n" + request  # Set a small, explicit output structure.
        result = llm.invoke(prompt)  # Convert the notes into useful outputs.
        st.markdown(result.content)  # Display the formatted result.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
