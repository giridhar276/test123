"""Expense Policy Checker — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Expense Policy Checker", page_icon="🤖")
st.title("Expense Policy Checker")
st.caption("Single agent + synthetic records | Beginner-friendly LangChain OpenAI demo")
st.markdown("A single agent reviews fictional expenses against a short sample policy and flags items for human review. It demonstrates extraction and rule-based explanation, not real approvals.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Training expenses", value='Employee: Maya | Team lunch | $28 | Receipt: yes\nEmployee: Omar | Dinner | $65 | Receipt: yes\nEmployee: Lee | Taxi | $22 | Receipt: no', height=140)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "Review these fictional expenses. Policy: meals up to $40 per person are within policy; taxi rides need a receipt. For each, give status and reason. This is training only.\n" + request  # Provide the sample rule and records.
        result = llm.invoke(prompt)  # Ask the assistant to explain its review.
        st.markdown(result.content)  # Show flags for discussion, not approval.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
