"""Sales Data Insights — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Sales Data Insights", page_icon="🤖")
st.title("Sales Data Insights")
st.caption("Analyst agent + synthetic CSV | Beginner-friendly LangChain OpenAI demo")
st.markdown("An analyst agent summarizes a tiny fictional sales dataset. It demonstrates passing data summaries to an LLM while keeping the dataset small and easy to inspect.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Synthetic sales CSV", value='Region,Product,Units,UnitPrice\nNorth,Notebook,30,4\nSouth,Notebook,18,4\nNorth,Pen,50,2\nWest,Pen,20,2\nSouth,Notebook,25,4', height=140)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "Summarize this synthetic sales CSV: give total sales, best-selling region, and one observation. Show your calculation assumptions.\n" + request  # Pass the small sample data as readable text.
        result = llm.invoke(prompt)  # Ask the analyst agent for a plain-language summary.
        st.markdown(result.content)  # Display results for discussion.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
