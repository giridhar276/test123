# Agentic AI Workflows for Non-Coders

Ten compact classroom demos using LangChain OpenAI. Every use case has a notebook (`.ipynb`) and a standalone Streamlit app (`_app.py`). Code is intentionally short, with brief markdown explanations and inline `#` comments.

## Setup

Use Python 3.11.9. Install packages:

```bash
pip install -r requirements.txt
```

Set your API key in the terminal before starting Jupyter or Streamlit:

```bash
# macOS/Linux
export OPENAI_API_KEY="your-key"

# Windows PowerShell
$env:OPENAI_API_KEY="your-key"
```

Run a notebook in Jupyter, or launch any app:

```bash
streamlit run 01_travel_planner_app.py
```

The UI also accepts the key directly for a classroom run. Avoid sharing or committing API keys. Synthetic sample files are under `data/`; the notebooks also include the small sample inline so they run from any folder.

## Use cases

1. Travel planner — single agent
2. FAQ support — single agent with supplied knowledge
3. Meeting notes assistant — single agent transforms input
4. Expense policy checker — single agent plus synthetic records
5. Researcher to writer — two-agent handoff
6. Complaint routing — triage agent to specialist
7. Loan application review — extractor to policy checker (fictional training criteria)
8. Marketing team — planner, writer, reviewer
9. Sales insights — analyst with synthetic CSV
10. Resume coach — resume reviewer to coach, with fictional resume data

These are instructional demos. LLM output may be incorrect. Human review is required, especially for money, employment, customer support, or other consequential decisions.
