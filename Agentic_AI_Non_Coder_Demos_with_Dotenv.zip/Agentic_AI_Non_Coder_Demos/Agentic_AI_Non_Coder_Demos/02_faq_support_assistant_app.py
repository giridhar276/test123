"""FAQ Support Assistant — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="FAQ Support Assistant", page_icon="🤖")
st.title("FAQ Support Assistant")
st.caption("Single agent with reference knowledge | Beginner-friendly LangChain OpenAI demo")
st.markdown("The agent answers from a small synthetic FAQ. It demonstrates grounding answers in supplied information and saying when the answer is not available.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_input("Ask the FAQ", value="Can I return an opened item?")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "Answer only from this 'Question: What is the return window?\nAnswer: Items can be returned within 30 days with a receipt.\n\nQuestion: How do I contact support?\nAnswer: Email help@example.com.\n\nQuestion: When are orders shipped?\nAnswer: Orders are usually prepared within 2 business days.'. If the answer is missing, say you do not know.\n" + FAQ + "\nQuestion: " + request  # Give the agent its reference facts.
        result = llm.invoke(prompt)  # Ask the FAQ assistant.
        st.markdown(result.content)  # Display its grounded answer.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
