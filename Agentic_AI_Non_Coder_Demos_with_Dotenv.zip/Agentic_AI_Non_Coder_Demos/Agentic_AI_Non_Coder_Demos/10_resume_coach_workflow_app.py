"""Resume Coach Workflow — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Resume Coach Workflow", page_icon="🤖")
st.title("Resume Coach Workflow")
st.caption("Resume reviewer → role matcher → coach | Beginner-friendly LangChain OpenAI demo")
st.markdown("A resume coach workflow reviews a fictional resume against a job description, identifies relevant strengths and gaps, then suggests improvements. It demonstrates agents collaborating on a personal-document task; use fictional data in class.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
resume = st.text_area("Fictional resume", value='Name: Jordan Lee (fictional)\nExperience: 2 years as customer support associate\nSkills: customer communication, Excel, ticket tracking\nAchievement: helped organize a shared FAQ\nEducation: Bachelor of Commerce', height=140)
job = st.text_area("Target job description", value='Customer success associate: communicate with customers, track issues, use spreadsheets, and maintain help content.', height=100)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        analysis = llm.invoke("From this fictional resume, list relevant skills and experience for the target job; do not invent facts.\nResume:\n" + resume + "\nJob:\n" + job).content  # Reviewer agent extracts relevant evidence.
        st.markdown("#### Resume review
" + analysis)  # Show evidence passed forward.
        suggestions = llm.invoke("Compare the evidence with the job and suggest three truthful improvements. Do not invent qualifications.\n" + analysis + "\nJob:\n" + job)  # Coach agent offers edits.
        st.markdown("#### Coach suggestions
" + suggestions.content)  # Display actionable suggestions.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
