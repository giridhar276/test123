"""Customer Complaint Routing — minimal Streamlit demonstration."""
import os
import streamlit as st
from dotenv import load_dotenv  # Read variables from the local .env file.
from langchain_openai import ChatOpenAI

load_dotenv()  # Load OPENAI_API_KEY from .env before reading environment variables.

st.set_page_config(page_title="Customer Complaint Routing", page_icon="🤖")
st.title("Customer Complaint Routing")
st.caption("Triage agent → specialist agent | Beginner-friendly LangChain OpenAI demo")
st.markdown("A triage agent identifies the complaint type and passes it to the matching specialist. It demonstrates routing and delegation to a focused agent.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read the key loaded from .env.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Customer message", value="My package has not arrived and tracking has not changed.")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Add OPENAI_API_KEY=your_key to the .env file, then restart the app.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        category = llm.invoke("Classify as Billing, Delivery, or Technical. Return only category and reason. Message: " + request).content  # Triage agent selects a route.
        st.markdown("#### Triage result\n" + category)  # Show the routing decision.
        team = "Billing" if "billing" in category.lower() else "Delivery" if "delivery" in category.lower() else "Technical"  # Map the category to one specialist.
        response = llm.invoke(f"You are a {team} support specialist. Write a polite first response; do not promise outcomes. Customer: {request}")  # Specialist drafts the reply.
        st.markdown(f"#### {team} specialist\n" + response.content)  # Show the handoff result.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
