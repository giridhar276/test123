"""Loan Document Review — minimal Streamlit demonstration."""
import os
import streamlit as st
from dotenv import load_dotenv  # Read variables from the local .env file.
from langchain_openai import ChatOpenAI

load_dotenv()  # Load OPENAI_API_KEY from .env before reading environment variables.

st.set_page_config(page_title="Loan Document Review", page_icon="🤖")
st.title("Loan Document Review")
st.caption("Extractor agent → policy checker | Beginner-friendly LangChain OpenAI demo")
st.markdown("An extractor agent reads fictional applicant details, then a policy agent checks them against simple training criteria. It demonstrates a multi-step document workflow; it does not make real lending decisions.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read the key loaded from .env.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Fictional application", value='Applicant: Alex Morgan\nMonthly income: $4,200\nRequested amount: $8,000\nDocuments listed: proof of income, address document', height=140)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Add OPENAI_API_KEY=your_key to the .env file, then restart the app.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        details = llm.invoke("Extract name, monthly income, requested amount, and listed documents. Mark missing details as Missing.\n" + request).content  # Extractor agent reads the fictional application.
        st.markdown("#### Extracted details\n" + details)  # Show what is passed to the next agent.
        review = llm.invoke("Training criteria only: income at least $3,000 and proof of income listed. Say Meets sample criteria or Needs human review and explain. No real decisions.\n" + details)  # Policy agent checks the extracted facts.
        st.markdown("#### Sample policy check\n" + review.content)  # Display a classroom-only result.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
