"""Expense Policy Checker — minimal Streamlit demonstration."""
import os
import streamlit as st
from dotenv import load_dotenv  # Read variables from the local .env file.
from langchain_openai import ChatOpenAI

load_dotenv()  # Load OPENAI_API_KEY from .env before reading environment variables.

st.set_page_config(page_title="Expense Policy Checker", page_icon="🤖")
st.title("Expense Policy Checker")
st.caption("Single agent + synthetic records | Beginner-friendly LangChain OpenAI demo")
st.markdown("A single agent reviews fictional expenses against a short sample policy and flags items for human review. It demonstrates extraction and rule-based explanation, not real approvals.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read the key loaded from .env.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Training expenses", value='Employee: Maya | Team lunch | $28 | Receipt: yes\nEmployee: Omar | Dinner | $65 | Receipt: yes\nEmployee: Lee | Taxi | $22 | Receipt: no', height=140)

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Add OPENAI_API_KEY=your_key to the .env file, then restart the app.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        prompt = "Review these fictional expenses. Policy: meals up to $40 per person are within policy; taxi rides need a receipt. For each, give status and reason. This is training only.\n" + request  # Provide the sample rule and records.
        result = llm.invoke(prompt)  # Ask the assistant to explain its review.
        st.markdown(result.content)  # Show flags for discussion, not approval.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
