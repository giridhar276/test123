# Agentic AI Workflows for Non-Coders

Ten short LangChain OpenAI demonstrations. Each example includes a Jupyter notebook and a standalone Streamlit app.

## Python 3.11.9 setup

1. Install dependencies: `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` in this folder.
3. Replace the sample value with your OpenAI API key: `OPENAI_API_KEY=your_actual_key`
4. Restart Jupyter or Streamlit after editing `.env`.
5. Run a notebook, or launch an app, for example: `streamlit run 01_travel_planner_app.py`

The apps and notebooks call `load_dotenv()` to load the key from `.env`. Never share the real `.env` file or commit it to source control.

Synthetic samples are in `data/`. These are fictional classroom examples.
