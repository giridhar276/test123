"""Researcher → Writer — minimal Streamlit demonstration."""
import os
import streamlit as st
from dotenv import load_dotenv  # Read variables from the local .env file.
from langchain_openai import ChatOpenAI

load_dotenv()  # Load OPENAI_API_KEY from .env before reading environment variables.

st.set_page_config(page_title="Researcher → Writer", page_icon="🤖")
st.title("Researcher → Writer")
st.caption("Two agents in sequence | Beginner-friendly LangChain OpenAI demo")
st.markdown("A researcher agent creates key points, then a writer agent turns them into a short brief. It demonstrates agent-to-agent handoff with a clear division of work.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read the key loaded from .env.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_input("Topic", value="Benefits of clear customer support FAQs")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Add OPENAI_API_KEY=your_key to the .env file, then restart the app.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        research = llm.invoke("List four beginner-friendly points about this topic; avoid unsupported statistics: " + request).content  # Agent 1 prepares notes.
        st.markdown("#### Researcher\n" + research)  # Make the handoff visible.
        brief = llm.invoke("Write a concise brief for non-technical managers from these notes:\n" + research)  # Agent 2 uses Agent 1's output.
        st.markdown("#### Writer\n" + brief.content)  # Show the completed brief.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
