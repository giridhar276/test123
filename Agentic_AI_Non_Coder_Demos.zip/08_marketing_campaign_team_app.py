"""Marketing Campaign Team — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Marketing Campaign Team", page_icon="🤖")
st.title("Marketing Campaign Team")
st.caption("Planner → writer → reviewer | Beginner-friendly LangChain OpenAI demo")
st.markdown("Three focused agents plan, draft, and review a campaign message. It demonstrates collaboration where each agent adds a distinct step.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_area("Campaign brief", value="Promote a weekend community book fair to local families.")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        plan = llm.invoke("Create a short campaign idea with audience, key message, and call to action: " + request).content  # Planner agent defines the campaign.
        st.markdown("#### Planner\n" + plan)  # Show the first handoff.
        draft = llm.invoke("Write a short social post from this campaign idea:\n" + plan).content  # Writer agent drafts content.
        st.markdown("#### Writer\n" + draft)  # Show the second handoff.
        reviewed = llm.invoke("Improve this post for clarity and friendly tone. Return only the improved post:\n" + draft)  # Reviewer agent polishes it.
        st.markdown("#### Reviewer\n" + reviewed.content)  # Show final output.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
