"""Researcher → Writer — minimal Streamlit demonstration."""
import os
import streamlit as st
from langchain_openai import ChatOpenAI

st.set_page_config(page_title="Researcher → Writer", page_icon="🤖")
st.title("Researcher → Writer")
st.caption("Two agents in sequence | Beginner-friendly LangChain OpenAI demo")
st.markdown("A researcher agent creates key points, then a writer agent turns them into a short brief. It demonstrates agent-to-agent handoff with a clear division of work.")

api_key = os.getenv("OPENAI_API_KEY", "")  # Read API key from environment; do not paste it into code.
if not api_key:
    api_key = st.text_input("OpenAI API key", type="password")  # Optional key entry for a live classroom demo.

model_name = st.text_input("Model", value="gpt-4.1-mini")  # Choose an available chat model.
request = st.text_input("Topic", value="Benefits of clear customer support FAQs")

if st.button("Run demo", type="primary"):
    if not api_key:
        st.error("Enter OPENAI_API_KEY in your environment or in the box above.")
    elif not request.strip():
        st.warning("Please enter some input first.")
    else:
        llm = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # One simple chat model powers each role.
        research = llm.invoke("List four beginner-friendly points about this topic; avoid unsupported statistics: " + request).content  # Agent 1 prepares notes.
        st.markdown("#### Researcher\n" + research)  # Make the handoff visible.
        brief = llm.invoke("Write a concise brief for non-technical managers from these notes:\n" + research)  # Agent 2 uses Agent 1's output.
        st.markdown("#### Writer\n" + brief.content)  # Show the completed brief.

st.caption("Training demo: verify outputs and keep a person in the decision loop.")
