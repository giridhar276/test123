"""Policy Exception Decision Board: Agents apply policy, discuss edge cases, and decide within rules."""
import os
import streamlit as st
from dotenv import load_dotenv  # Load API settings from .env.
from langchain_openai import ChatOpenAI

load_dotenv()  # Read OPENAI_API_KEY from the local .env file.
st.set_page_config(page_title='Policy Exception Decision Board', page_icon="🤝")
st.title('Policy Exception Decision Board')
st.caption('Agents apply policy, discuss edge cases, and decide within rules')
st.markdown('Policy, evidence, and manager agents assess a fictional meal expense against a sample rule and return a bounded recommendation.')
case = st.text_area('Request and sample policy', value='Request: $78 meal for 2 employees on approved travel. Receipt attached. Sample rule: meals reimbursed up to $40/person with receipt. Above limit requires manager approval.', height=150)  # Edit the fictional case.
model_name = st.text_input("OpenAI model", "gpt-4.1-mini")  # Choose the model used for role prompts.

if st.button("Run workflow", type="primary"):
    api_key = os.getenv("OPENAI_API_KEY")  # Use the value loaded from .env.
    if not api_key:
        st.error("Add OPENAI_API_KEY=your_key to .env, then restart Streamlit.")
    else:
        model = ChatOpenAI(model=model_name, api_key=api_key, temperature=0)  # Set up the chat model.
        reports = []  # Keep each agent message for the next handoff.
        def ask_agent(role, task, context):
            prompt = f"You are {role}. {task}\n\nCase facts and prior reports:\n{context}"  # Give each role its task.
            return model.invoke(prompt).content  # Run the role and return its response.
        goal = "Complete the defined task using the available evidence."  # Define the target.
        plan = ask_agent("Workflow planner", "Plan short steps using only these configured roles: Policy agent, Evidence agent, Manager agent", case)  # Ask the LLM to plan.
        st.subheader("Plan")
        st.write(plan)  # Show the plan before actions.
        reports = []  # Store agent messages as observations and handoffs.
        report = ask_agent('Policy agent', 'Apply rule and calculate per-person amount.', case)  # Run this agent role.
        reports.append(report)  # Keep its message for later roles.
        with st.expander('Policy agent', expanded=False):
            st.write(report)  # Show the agent message and handoff.
        report = ask_agent('Evidence agent', 'Check whether required evidence is included.', case)  # Run this agent role.
        reports.append(report)  # Keep its message for later roles.
        with st.expander('Evidence agent', expanded=False):
            st.write(report)  # Show the agent message and handoff.
        report = ask_agent('Manager agent', 'Review findings. Choose Approve, Decline, or Human review. Explain and name any further approval required.', case + "\n\nPrior agent messages:\n" + "\n".join(reports))  # Run this agent role.
        reports.append(report)  # Keep its message for later roles.
        with st.expander('Manager agent', expanded=True):
            st.write(report)  # Show the agent message and handoff.
        observation = ask_agent("Observer", "Summarize the results and evidence from the agent messages.", case + "\n\nAgent messages:\n" + "\n".join(reports))  # Observe the actions.
        st.subheader("Observed results")
        st.write(observation)
        complete = False
        for attempt in range(2):  # Limit the workflow to two review rounds.
            status = ask_agent("Goal checker", "Reply COMPLETE if goal is met; otherwise NEEDS_REVISION and one specific fix.", goal + "\n\n" + observation)  # Check the result.
            st.write(f"Check {attempt + 1}: {status}")
            if status.strip().upper().startswith("COMPLETE"):
                complete = True
                break  # Stop when the goal checker approves completion.
            observation = ask_agent("Workflow coordinator", "Apply the checker’s fix and return an improved result.", observation + "\n\nChecker: " + status)  # Iterate using feedback.
            st.write(observation)
        if not complete:
            st.warning("Iteration limit reached. A person should review the result.")
        st.info("Fictional classroom simulation. Review before taking action.")
