# Collaborative Agent Workflows for Non-Coders

Ten realistic classroom scenarios demonstrate delegation, debate, disagreement, voting, specialist routing, parallel analysis, red-team review, bounded decisions, and human approval. Each has its own notebook and Streamlit app.

## Setup with Python 3.11.9
Install dependencies with pip install -r requirements.txt. Copy .env.example to .env, enter OPENAI_API_KEY=your_actual_key, and restart Jupyter or Streamlit. Every notebook and app calls load_dotenv(). Keep your real .env private.

Launch an app with streamlit run 01_project_manager_delegation_app.py.

The cases and records are fictional but model common business operations. These short role-based demonstrations do not connect to live systems. Production deployment also needs authenticated integrations, access controls, audit logs, monitoring, evaluation, error handling, and human approval where appropriate.
